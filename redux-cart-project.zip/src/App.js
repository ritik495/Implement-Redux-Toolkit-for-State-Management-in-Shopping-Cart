import React from "react";
import { createRoot } from "react-dom/client";
import { Provider, useDispatch, useSelector } from "react-redux";
import { configureStore, createSlice } from "@reduxjs/toolkit";
import "./index.css";

const cartSlice = createSlice({
  name: "cart",
  initialState: { items: [] },
  reducers: {
    addToCart: (state, action) => {
      const item = state.items.find((i) => i.name === action.payload.name);
      if (item) item.quantity += 1;
      else state.items.push({ ...action.payload, quantity: 1 });
    },
    removeFromCart: (state, action) => {
      state.items = state.items.filter((i) => i.name !== action.payload);
    },
    updateQuantity: (state, action) => {
      const item = state.items.find((i) => i.name === action.payload.name);
      if (item) item.quantity = action.payload.quantity;
    },
  },
});

const { addToCart, removeFromCart, updateQuantity } = cartSlice.actions;

const store = configureStore({ reducer: { cart: cartSlice.reducer } });

const ProductList = () => {
  const dispatch = useDispatch();
  const products = [
    { name: "Laptop", price: 1200 },
    { name: "Mouse", price: 25 },
    { name: "Keyboard", price: 45 },
  ];
  return (
    <div className="products">
      <h2>Products</h2>
      <div className="product-list">
        {products.map((p) => (
          <div key={p.name} className="product">
            <h3>{p.name}</h3>
            <p>${p.price}</p>
            <button onClick={() => dispatch(addToCart(p))}>Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  );
};

const Cart = () => {
  const dispatch = useDispatch();
  const cartItems = useSelector((state) => state.cart.items);
  return (
    <div className="cart">
      <h2>Shopping Cart</h2>
      {cartItems.length === 0 ? (
        <p>Your cart is empty</p>
      ) : (
        cartItems.map((item) => (
          <div key={item.name} className="cart-item">
            <span>
              {item.name} (${item.price})
            </span>
            <input
              type="number"
              value={item.quantity}
              min="1"
              onChange={(e) =>
                dispatch(
                  updateQuantity({
                    name: item.name,
                    quantity: parseInt(e.target.value),
                  })
                )
              }
            />
            <button onClick={() => dispatch(removeFromCart(item.name))}>
              Remove
            </button>
          </div>
        ))
      )}
    </div>
  );
};

const App = () => (
  <div className="app">
    <h1>My Shop</h1>
    <ProductList />
    <Cart />
  </div>
);

const root = createRoot(document.getElementById("root"));
root.render(
  <Provider store={store}>
    <App />
  </Provider>
);
